# CloudCounselage-Chatbot
A chatbot that assists interns of CloudCounselage Pvt. Ltd. to get their queries solved.

To use it in your system follow the folloing steps:
1) Unzip the file first.
2) Now come to the root directory of folder i.e.    "CloudCounselage-Chatbot" in terminal or command prompt.
3) Run the command "npm run start".
4) "Server is listening at port: 5000" message will appear in terminal/cmd.
5) Open chrome/firefox/safari and visit "localhost:5000".
6) Congrats, you have reached the destination. Now begin with your queries.

Prerequisites:
Install Node JS in advance.
If not done previously run command "npm install"

